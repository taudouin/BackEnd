module.exports = {
    get: (req, res) => {
        res.render('success_article')
    }
}