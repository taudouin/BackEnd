module.exports = {
    get: (req, res) => {
        res.render('login')
    }
}