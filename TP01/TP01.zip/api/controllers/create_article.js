module.exports = {
    get: (req, res) => {
        res.render('create_article')
    }
}